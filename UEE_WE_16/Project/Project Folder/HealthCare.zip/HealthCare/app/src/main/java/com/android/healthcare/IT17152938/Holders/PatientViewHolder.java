package com.android.healthcare.IT17152938.Holders;

import android.widget.Button;
import android.widget.TextView;

public class PatientViewHolder {
    public TextView name,date;
    public Button edit,delete;

}
