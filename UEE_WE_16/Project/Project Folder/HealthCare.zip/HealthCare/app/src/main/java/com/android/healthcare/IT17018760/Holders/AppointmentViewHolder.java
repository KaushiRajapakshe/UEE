package com.android.healthcare.IT17018760.Holders;

import android.widget.Button;
import android.widget.TextView;

public class AppointmentViewHolder {
    public TextView patientName;
    public Button edit,delete;

}

