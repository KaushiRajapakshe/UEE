package com.android.healthcare.IT17056212.bean;

public interface AdapterCallback {
    public void edit(int id);
    public void refreshlist();
    public void openDetails(int id);
}
