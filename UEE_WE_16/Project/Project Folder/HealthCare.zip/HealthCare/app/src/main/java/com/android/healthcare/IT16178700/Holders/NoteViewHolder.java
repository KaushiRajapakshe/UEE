package com.android.healthcare.IT16178700.Holders;

import android.widget.Button;
import android.widget.TextView;

public class NoteViewHolder {
    public TextView title;
    public Button edit,delete;

}
