package com.android.healthcare.IT17152938.bean;

public interface AdapterCallback {
    public void edit(int id);
    public void refreshlist();
    public void openDetails(int id);
}
