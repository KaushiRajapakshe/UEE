package com.android.healthcare.IT16178700.bean;

public interface AdapterCallback {
    public void edit(int id);
    public void refreshlist();
    public void openDetails(int id);
}
