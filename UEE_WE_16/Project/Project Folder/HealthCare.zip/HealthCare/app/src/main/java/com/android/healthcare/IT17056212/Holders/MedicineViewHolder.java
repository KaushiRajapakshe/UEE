package com.android.healthcare.IT17056212.Holders;

import android.widget.Button;
import android.widget.TextView;

public class MedicineViewHolder {
    public TextView drugName,expiryDate;
    public Button edit,delete;

}
